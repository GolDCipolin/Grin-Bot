import random

grinlist = ["<:hisuGrin:1021914953378189352>","<:Xor:1040414989149814834>",'<:norvil:1024319878611607674>','<:nor:1023985686979809291>','<:Akenogrin:1012017764740911194>','<:AndyGrin:1017911206952042496>','<:AyanoGrin:1017117987775451247>','<:Finor:1023985438861570109>','\<:FlochGrin:1034536133591302234>','<:FlochGrin2:1034569207951671467>','<:HarribelGrin:1037034653963530411>','<:Irvingrin:1013151359773704253>','<:LucyGrin:1038202901581017139>','<:Miliagrin:1020522277340708984>','<:Raygrin:1014566895296454666>','<:Riasgrin:1012017702514204733>',
            '<:RukiaGrin:1017904026953715712>','<:ShirouGrin:1034238355107483689>','<:TinyGrin:1017218737499287642>','<:ValentineGrin:1040038569525399574>','<:WeskerGrin:1034216012536627225>','<:WeskerGrin2:1034216081105096755>','<:WeskerNor:1040240712958083102>','<:blackholeXor:1040416765622099968>','<:chibased:1007430095226535956>','<:evilnor:1040240274200350761>','<:evilnor100:1040241589739585627>','<:multiversalGrin:1040422796473421855>','<:nor2:1023985364530110566>','<:nor3:1023985396310356028>','<:nor4:1023985418577911889>','<:norShield:1030597255398436974>',
            '<:redhgrin:1014193833300459590>','<:xenoviagrin:1014143744880169052>','<:madeinxor:1053694096113410068>','<:illusionGrin:1050059068875739217>','<:mathGrin:1050059111531814943>']

def get_response(message: str) -> str:

    p_message = message.lower()

    if p_message == '-grin':
        index=random.randint(0,37)
        return grinlist[index]

    if p_message == '-help grin':
        return 'There is no help you retard. The fact that you had to type up -help is retarded within it self. Please just go rethink about your life choices. Just type `-grin` .'

    return